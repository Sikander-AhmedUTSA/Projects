#include "champion.h"

Champion* createChampion() { // Creates the champion and sets its level and role.

    Champion *temp = (Champion*)malloc(sizeof(Champion));
    temp->next = NULL; // add the head pointer

    int random1 = rand() % 4; // Setting the Role
    int random2 = rand() % 4;
    if (random1 == 0) { 
        temp->role = MAGE;
    } else if (random1 == 1) {
        temp->role = FIGHTER;
    } else if (random1 == 2) {
        temp->role = SUPPORT;
    } else {
        temp->role = TANK;
    }

    if (temp->role == MAGE) { // Setting the level based on the role.
        temp->level = rand() % (8 - 1 + 1) + 1; 
    } else if (temp->role == FIGHTER) {
        temp->level = rand() % (7 - 2 + 1) + 2; 
    } else if (temp->role == SUPPORT) {
        temp->level = rand() % (6 - 3 + 1) + 3; 
    } else if (temp->role == TANK) {
        temp->level = rand() % (9 - 6 + 1) + 6; 
    }

    return temp;
}

Champion* addChampion(Champion *head, Champion *c) { // Adds a champion to an already existing list.

    Champion* cur = head;
    Champion* prev = NULL;

    while ((cur != NULL) && (cur->level >= c->level)) {
        prev = cur;
        cur = cur->next;
    }

    if (prev == NULL) {
        c->next = cur;
        return c;
    }

    prev->next = c;
    c->next = cur;
    return head;
}

Champion* buildChampionList(int n) { // Builds the champion list based on how big n is.
    int i;
    Champion *head = NULL;

    for (i=0; i<n; ++i) {
      Champion *temp = createChampion();
      head = addChampion(head, temp);
     }
    return head;
}

void printChampionList(Champion* head) { // Prints the Champion List in (Role)(Level).
    Champion *temp = head;
    while (temp != NULL) {
        if (temp->role == MAGE) { 
        printf("M%d ", temp->level);
    } else if (temp->role == FIGHTER) {
        printf("F%d ", temp->level);
    } else if (temp->role == SUPPORT) {
        printf("M%d ", temp->level);
    } else if (temp->role == TANK) {
        printf("T%d ", temp->level);
    }
        temp = temp->next;
    }

    printf("\n");
}

Champion* removeChampion(Champion *head) { // Removes the first champion from the list.
    Champion* temp = head->next;
    head = temp;
    return head;
}

Champion* destroyChampionList(Champion *head) { // Destroys the champion entirely.
    Champion* cur = head;
    Champion *next;

    while(cur != NULL) {
      next = cur->next;
      free(cur);
      cur = cur->next;
    }

    return NULL;
}
