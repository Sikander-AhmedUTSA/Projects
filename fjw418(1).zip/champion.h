#ifndef CHAMPION_H
#define CHAMPION_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


enum ChampionRole {MAGE, FIGHTER, SUPPORT, TANK};

typedef struct champion_struct {
    enum ChampionRole role;
    int level;
    struct Champion* next;
} Champion;

Champion* createChampion();

Champion* addChampion(Champion *head, Champion *c);

Champion* buildChampionList(int n);

void printChampionList(Champion* head);

Champion* removeChampion(Champion *head);

Champion* destroyChampionList(Champion *head);


#endif 
