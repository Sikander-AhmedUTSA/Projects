#include "route-records.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


RouteRecord* createRecords(FILE* inputFile) { // This function creates the array of RouteRecord’s and initializes it. 
    char buffer[25];
    fgets(buffer, 25, inputFile);
    int i = 0;
    while (!feof(inputFile)) {
        fgets(buffer, 25, inputFile);
        i++;
    }
    RouteRecord* records = (RouteRecord*)malloc(i*sizeof(RouteRecord));
    int j;
    for (j = 0; j < i; j++) {
        records->passengers[j] = 0;
    }
    rewind(inputFile);
    return records;
}

int fillRecords(RouteRecord* r, FILE* inputFile) { // This function will process the data in the CSV file.
    int i = 0;
    int placeHolder = 0;
    int length = 0;
    char tempBuffer[25];
    fgets(tempBuffer, 25, inputFile);

    while (!feof(inputFile)) {
        length++;
    }
    rewind(inputFile);
    fgets(tempBuffer, 25, inputFile);

    while(!feof(inputFile)) {
        if (strlen(r->airlineCode[i] == 3)) {
            continue;
        }
        fscanf(inputFile,"%d,%3s,%3s,%3s,%d", &r->month[i], r->origCode[i], r->destCode[i], r->airlineCode[i], &r->passengers[i][r.month[i]-1]);
        placeHolder = findAirlineRoute(&r, length, r->originCode[i], r->destCode.[i], r->airlineCode[i], i); 

        if (placeHolder != -1) {
            r.passengers[i][r.month[i]-1] += r.passengers[placeHolder][r.month[placeHolder]-1];
        } else {
            fscanf(inputFile,"%d,%3s,%3s,%3s,%d", &r.month[i], r.origCode[i], r.destCode[i], r.airlineCode[i], &r.passengers[i][r.month[i]-1]);
            i++;
        }
        }

    return i;
    }
 

int findAirlineRoute(RouteRecord* r, int length, const char* origin, const char* destination, const char* airline, int curIndex) { // This recursive function finds a record in the RouteRecord array with the same origin and dest codes and airline and returns the index in which they appear in the array.
int i;

for (i = curIndex , i > 1, --i) {
    if (i == 2) {
        return -1;
    }
    if ((i != curIndex) && (strcmp(r->originCode[i], &destination) == 0) && (strcmp(r->destCode[i], &destination) == 0) && (strcmp(r->airlineCode[i], &airline) == 0)) {
        return findAirlineRoute(&r, length, r->originCode[i], r->destCode.[i], r->airlineCode[i], i);
    }
}
}


void searchRecords(RouteRecord* r, int length, const char* key1, const char key2, SearchType st) { // This function searches the RouteRecord array and prints out the results of the search.
int i; // first line is header so need to skip it
int count = 0;
int totalPassengers = [0,0,0,0,0,0,0,0,0,0,];  // 0 through 9 are monthly passengers and 10 is total passengers

if(st == ROUTE) {
    for (i=1; i < length; ++i) {
        if((strcmp(key1, r->originCode[i]) == 0) && (strcmp(key2, r->destCode[i]) == 0) {
            printf("%s (%s-%s)", r->airlineCode[i], r->originCode[i], r->destCode[i]);
            count++;
            totalPassengers[9] += r.passengers[i][r.month[i]-1];
            totalPassengers[r.month[i-1]] += r.passengers[i][r.month[i-1]]; 
        }
    }   
} else if (st == ORIGIN) {
    for (i=1; i < length; ++i) {
        if(strcmp(key1, r.originCode[i]) == 0) {
            printf("%s (%s-%s)", r->airlineCode[i], r->originCode[i], r->destCode[i]);
            count++;
            totalPassengers[9] += r.passengers[i][r.month[i]-1];
            totalPassengers[r.month[i-1]] += r.passengers[i][r.month[i-1]]; 
        }
    }  
} else if (st == DESTINATION) {
    for (i=1; i < length; ++i) {
        if(strcmp(key1, r.destCode[i]) == 0) {
            printf("%s (%s-%s)", r->airlineCode[i], r->originCode[i], r->destCode[i]);
            count++;
            totalPassengers[9] += r.passengers[i][r.month[i]-1];
            totalPassengers[r.month[i-1]] += r.passengers[i][r.month[i-1]]; 
        }
    }  
} else if (st == AIRLINE) {
for (i=1; i < length; ++i) {
        if(strcmp(key1, r.airlineCode[i]) == 0) {
            printf("%s (%s-%s)", r->airlineCode[i], r->originCode[i], r->destCode[i]);
            count++;
            totalPassengers[9] += r.passengers[i][r.month[i]-1];
            totalPassengers[r.month[i-1]] += r.passengers[i][r.month[i-1]]; 
        }
    }  
}
printf("\n %d matches were found.\nStatistics\n", &count);
printf("Total Passengers: %d\n", &totalPassengers);
for(i = 0; i< 9; ++i) {
    printf("Total Passengers in Month %d:\t\n", i+1, totalPassengers[i]);
}
printf("Average Passengers per Month: \t%d\n", ((int) totalPassengers[9]/count));

return NULL;
}
void printMenu() { // This function prints the menu.
printf( "\n\n######### Airline Route Records Database MENU #########\n" );
printf( "1. Search by Route\n" );
printf( "2. Search by Origin Airport\n" );
printf( "3. Search by Destination Airport\n" );
printf( "4. Search by Airline\n" );
printf( "5. Quit\n" );
printf( "Enter your selection: " );
}

