#include <stdio.h>
#include <stdlib.h>
#include "route-records.h"

int main( int argc, char *argv[])
{
    int menuNum; // Declaring variables
    FILE* inputFile = NULL;
    int tempNum = 0;
    //SearchType st;
    char key1[5];
    char key2[5];

    int length = 0;

    if(argv[1] == NULL || argc < 2) { // Making sure file exists and opening it
        printf("ERROR: Missing file name and end the program\n");
        return -1;
    }
    printf("Opening %s...\n", argv[1]);
    inputFile = fopen(argv[1], "r");
    if (inputFile == NULL) {
        printf("ERROR: Could not open file and end the program.\n");
        return -1;
    }   


    RouteRecord *records = CreateRecords(&inputFile); // Creating records and extras
    tempNum = fillRecords(records, inputFile);
    printf("Unique routes operated by airlines: %d", &tempNum);
    rewind(inputFile);

    while(!feof(inputFile)) {
        length++;
    }
    fclose(inputFile);

    
    while (1) { // Main menu screen
        printMenu();
        scanf("%d", &menuNum);

        switch(menuNum) {
            case 1:
                printf("Enter origin: \n");
                scanf("%s", key1);
                printf("Enter destination: \n");
                scanf("%s", key2);
                searchRecords(records, length, key1, key2, ROUTE);
                break;
            case 2:
                printf("Enter origin: \n");
                scanf("%s", key1);
                searchRecords(records, length, key1, "NULL", ORIGIN);
                break;
            case 3:
                printf("Enter destination: \n");
                scanf("%s", key1);
                searchRecords(records, length, key1, "NULL", DESTINATION);
                break;
            case 4:
                printf("Enter airline: \n");
                scanf("%s", key1);
                searchRecords(records, length, key1, "NULL", AIRLINE);
                break;
            case 5:
                break;
            default:
                printf("Please try again:\n");
                break;
        }

         if (menuNum == 5) {
            break;
         }
    }
    printf("Thank you for using, this took me too much time to make :(\n");
    free(records);

    return 0;
}
