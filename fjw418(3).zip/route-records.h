#ifndef ROUTE_RECORDS_H
#define ROUTE_RECORDS_H
#include <stdio.h>


typedef struct routeRecords_struct { // Creating record structure
    int month;
    char originCode[3];
    char destCode[3];
    int airlineCode[3];
    int passengers[9];
} RouteRecord;

typedef enum SearchType {ROUTE, ORIGIN, DESTINATION, AIRLINE} SearchType;

RouteRecord* createRecords(FILE* inputFile);

int fillRecords(RouteRecord* r, FILE* inputFile);

int findAirlineRoute(RouteRecord* r, int length, const char* origin, const char* destination, const char* airline, int curIndex);

void searchRecords(RouteRecord* r, int length, const char* key1, const char key2, SearchType st);

void printMenu();

#endif