#include <stdio.h>
#include "dicegame.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>

int getRandomNumber(int min, int max) { // creates a function that gets a random number between two bounds inclusive
return ((rand() % (max + 1 - min)) + min);
}

enum ROUNDTYPE getRoundType() { // creates a function that gets a random enum ROUNDTYPE

int num = getRandomNumber(0,9);
if(num < 5) {
return REGULAR;
} else if (num > 7) {
return BONUS;
} else {
return DOUBLE;
}

}

int getRoundPoints(enum ROUNDTYPE roundType) { // creates a function that gets a random amount of points based on the ROUNDTYPE 
int num = 10 * getRandomNumber(1,10);

if(roundType == REGULAR) {
return num;
} else if (roundType == BONUS) {
return 200;
} else {
return (num * 2);
} 

}

void printPlayerPoints(int p1, int p2) { // creates a function that displays player points

printf("p1: %d\n", p1);
printf("p2: %d\n\n", p2);

}

void printRoundInfo(enum ROUNDTYPE t, int dice, int points) { // creates a function that prints other info like ROUNDTYOE, # on dice etc.

if (t == BONUS) {
printf("Type\t: BONUS\n");
} else if (t == REGULAR) {
printf("Type\t: REGULAR\n");
} else {
printf("Type\t: DOUBLE\n");
}

printf("DICE\t: %d\n", dice);
printf("POINTS\t: %d\n", points);

}
