#include <stdio.h>
#include "dicegame.h"
#include <stdlib.h>
#include <time.h>



int main() {

int p1, p2, i, rounds, dice, pointsHolder, roundDetermine; // declaring all variables needed
enum ROUNDTYPE roundType;

printf("Project 1 done by fjw418\n"); 
printf("Enter the number of rounds:\n");
scanf("%d", &rounds);

srand(time(NULL)); // setting up general info llke points and determining who goes first
p1 = 0;
p2 = 0;	
printPlayerPoints(p1, p2);

roundDetermine = getRandomNumber(1, 2);
if (roundDetermine == 1) {
printf("p1 first:\n");
} else {
printf("p2 first:\n");
}

i = 1;
while (i <= rounds) { // main game logic

while (roundDetermine % 2 != 0) {  // player 1
dice = getRandomNumber(1,6);
roundType = getRoundType();
pointsHolder = getRoundPoints(roundType);

if (roundType == REGULAR) { // Regular
   if (dice % 2 != 0) {
      p1 += pointsHolder;
   } else {
      p1 -= pointsHolder;
      roundDetermine++;
   }
} else if (roundType == BONUS) { // Bonus
   if (dice % 2 != 0) {
      p1 += 200;
   } else {
      p1 -= 200;
      roundDetermine++;
   }
} else { // Double
   if (dice % 2 != 0) {
      p1 += 2 * pointsHolder;
   } else {
      p1 -= 2 * pointsHolder;
      roundDetermine++;
   }
}

printf("Round %d\n", i); // printing round info
printRoundInfo(roundType, dice, pointsHolder);
printPlayerPoints(p1, p2);
i++;
if (i == rounds + 1) {
break;
}
}

if (i == rounds + 1) { // checking round count
break;
}


while (roundDetermine % 2 == 0) { // player 2
dice = getRandomNumber(1,6);
roundType = getRoundType();
pointsHolder = getRoundPoints(roundType);

if (roundType == REGULAR) { // Regular
   if (dice % 2 == 0) {
      p2 += pointsHolder;
   } else {
      p2 -= pointsHolder;
      roundDetermine++;
   }
} else if (roundType == BONUS) { // Bonus
   if (dice % 2 == 0) {
      p2 += 200;
   } else {
      p2 -= 200;
      roundDetermine++;
   }
} else {
   if (dice % 2 == 0) { // Double
      p2 += 2 * pointsHolder;
   } else {
      p2 -= 2 * pointsHolder;
      roundDetermine++;
   }
}

printf("Round %d\n", i); // printing round info
printRoundInfo(roundType, dice, pointsHolder);
printPlayerPoints(p1, p2);
i++;
if (i == rounds + 1) {
break;
}
}

}

printf("\nGAME OVER!!\n"); // game over info
if (p1 > p2) {
printf("p1 Won\n");
} else if (p1 < p2) {
printf("P2 Won\n");
} else {
printf("Tied\n");
}

return 0;	

}
